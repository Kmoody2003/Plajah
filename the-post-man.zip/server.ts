import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import dotenv from "dotenv";
import { google } from "googleapis";
import { initializeApp, getApps, getApp } from "firebase-admin/app";
import { getFirestore } from "firebase-admin/firestore";
import firebaseConfig from "./firebase-applet-config.json";

dotenv.config();

// Initialize Firebase Admin safely
const adminApp = getApps().length === 0 
  ? initializeApp({
      projectId: firebaseConfig.projectId,
    }) 
  : getApp();

// Access the specific database provisioned for this applet
const db = getFirestore(adminApp, firebaseConfig.firestoreDatabaseId);

// Verify database connection on startup
(async () => {
  try {
    const testDoc = await db.collection('_health').doc('connection').get();
    console.log("Firebase Database Connection: OK");
  } catch (error) {
    console.error("Firebase Database Connection Error:", error);
  }
})();

const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;
const APP_URL = process.env.APP_URL || 'http://localhost:3000';
const REDIRECT_URI = `${APP_URL}/auth/callback`;

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/debug/info", (req, res) => {
    res.json({
      nodeEnv: process.env.NODE_ENV,
      projectId: firebaseConfig.projectId,
      databaseId: firebaseConfig.firestoreDatabaseId,
      hasGoogleId: !!process.env.GOOGLE_CLIENT_ID,
      hasGoogleSecret: !!process.env.GOOGLE_CLIENT_SECRET,
      appUrl: process.env.APP_URL
    });
  });

  // OAuth Client Helper
  const getGoogleAuthClient = () => {
    return new google.auth.OAuth2(GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, REDIRECT_URI);
  };

  // OAuth URL generators
  app.get("/api/auth/google/url", (req, res) => {
    const oauth2Client = getGoogleAuthClient();
    const url = oauth2Client.generateAuthUrl({
      access_type: "offline",
      response_type: "code",
      prompt: "consent",
      scope: [
        "https://www.googleapis.com/auth/userinfo.profile",
        "https://www.googleapis.com/auth/userinfo.email",
        "https://www.googleapis.com/auth/gmail.readonly"
      ],
      state: "google",
    });
    res.json({ url });
  });

  app.get("/api/auth/microsoft/url", (req, res) => {
    // Keep Microsoft as mock for now or implement similarly
    const rootUrl = "https://login.microsoftonline.com/common/oauth2/v2.0/authorize";
    const options = {
      client_id: process.env.MICROSOFT_CLIENT_ID || "",
      response_type: "code",
      redirect_uri: REDIRECT_URI,
      response_mode: "query",
      scope: "openid profile email User.Read Mail.Read Calendars.Read",
      state: "microsoft",
    };
    const qs = new URLSearchParams(options);
    res.json({ url: `${rootUrl}?${qs.toString()}` });
  });

  // Unified Callback handler
  app.get("/auth/callback", async (req, res) => {
    const { code, state } = req.query;

    if (state === "google" && typeof code === "string") {
      try {
        const oauth2Client = getGoogleAuthClient();
        const { tokens } = await oauth2Client.getToken(code);
        oauth2Client.setCredentials(tokens);

        // Get user info to identify the account
        const oauth2 = google.oauth2({ version: "v2", auth: oauth2Client });
        const userInfo = await oauth2.userinfo.get();
        const email = userInfo.data.email;

        if (email) {
          // Store tokens in Firestore
          // Using a fixed userId "default_user" for now as we don't have frontend auth yet
          const accountRef = db.collection("users").doc("default_user").collection("accounts").doc(email);
          await accountRef.set({
            provider: "google",
            email: email,
            accessToken: tokens.access_token,
            refreshToken: tokens.refresh_token,
            expiresAt: tokens.expiry_date,
            connectedAt: new Date().toISOString()
          }, { merge: true });
        }

        return res.send(callbackSuccessHtml("google"));
      } catch (error) {
        console.error("Google Auth Callback Error:", error);
        return res.status(500).send("Authentication failed");
      }
    }
    
    // Default fallback (Microsoft or others)
    res.send(callbackSuccessHtml(state as string || "unknown"));
  });

  // API to fetch real emails
  app.get("/api/gmail/list", async (req, res) => {
    try {
      // For now, get the first google account for default_user
      const accountsSnapshot = await db.collection("users").doc("default_user").collection("accounts")
        .where("provider", "==", "google")
        .limit(1)
        .get();

      if (accountsSnapshot.empty) {
        return res.status(404).json({ error: "No connected Gmail account found" });
      }

      const accountData = accountsSnapshot.docs[0].data();
      const oauth2Client = getGoogleAuthClient();
      oauth2Client.setCredentials({
        access_token: accountData.accessToken,
        refresh_token: accountData.refreshToken,
        expiry_date: accountData.expiresAt
      });

      const gmail = google.gmail({ version: "v1", auth: oauth2Client });
      const response = await gmail.users.messages.list({
        userId: "me",
        maxResults: 10
      });

      const messages = response.data.messages || [];
      const detailedMessages = await Promise.all(messages.map(async (msg) => {
        const fullMsg = await gmail.users.messages.get({ userId: "me", id: msg.id! });
        const headers = fullMsg.data.payload?.headers || [];
        const subject = headers.find(h => h.name === "Subject")?.value || "(No Subject)";
        const from = headers.find(h => h.name === "From")?.value || "Unknown";
        const date = headers.find(h => h.name === "Date")?.value || "";
        
        return {
          id: msg.id,
          sender: from,
          subject: subject,
          preview: fullMsg.data.snippet,
          time: date,
          read: !fullMsg.data.labelIds?.includes("UNREAD"),
          starred: fullMsg.data.labelIds?.includes("STARRED"),
          avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(from)}&background=random`
        };
      }));

      res.json(detailedMessages);
    } catch (error: any) {
      console.error("Gmail Fetch Error Detail:", error);
      res.status(500).json({ 
        error: "Failed to fetch emails", 
        message: error.message,
        code: error.code
      });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

function callbackSuccessHtml(provider: string) {
  return `
    <html>
      <head>
        <title>Authentication Successful</title>
        <style>
          body { font-family: sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; background: #0f1218; color: #fff; }
          .container { text-align: center; padding: 3rem; border-radius: 2rem; background: rgba(255,255,255,0.05); backdrop-filter: blur(24px); border: 1px solid rgba(255,255,255,0.12); }
          .icon { font-size: 3rem; margin-bottom: 1rem; }
          .serif { font-family: Georgia, serif; font-style: italic; color: #fb7185; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="icon">✨</div>
          <h1>Connected to <span class="serif">${provider}</span></h1>
          <p>The Post Man is now in sync.</p>
          <p>This window will close automatically.</p>
        </div>
        <script>
          if (window.opener) {
            window.opener.postMessage({ type: 'OAUTH_AUTH_SUCCESS', provider: '${provider}' }, '*');
            setTimeout(() => window.close(), 2500);
          }
        </script>
      </body>
    </html>
  `;
}

startServer();
