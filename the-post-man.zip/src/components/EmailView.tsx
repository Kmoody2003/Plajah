import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mail, Send, Paperclip, Sparkles, X, ChevronRight, Star, Archive, Trash2, Reply, Forward, MoreVertical, Loader2, PenLine, RefreshCw, Layout as LayoutIcon, Box, Waves as AbyssIcon, Cloud, Rocket, Globe, Zap, Anchor } from 'lucide-react';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Link from '@tiptap/extension-link';
import Underline from '@tiptap/extension-underline';
import { GoogleGenAI } from "@google/genai";
import { toast } from 'sonner';
import type { LayoutType, ExperienceType } from '../App';

// --- Types ---
type Email = {
  id: string;
  sender: string;
  subject: string;
  preview: string;
  time: string;
  read: boolean;
  starred: boolean;
  avatar: string;
  category?: string;
};

const DEMO_EMAILS: Email[] = [
  { id: '1', sender: 'Coral Research Lab', subject: 'Deep Sea Bioluminescence Analysis', preview: 'The latest samples from the Mariana Trench show unexpected patterns of photon emission in the 450nm range...', time: '2 min ago', read: false, starred: false, avatar: 'https://picsum.photos/seed/coral/100/100', category: 'Priority' },
  { id: '2', sender: 'Nexus Protocol', subject: 'Encrypted Payload Received', preview: 'Verification required for data stream 77X-Beta. The sync matrices for the neural link are now operational.', time: '1 hour ago', read: true, starred: true, avatar: 'https://picsum.photos/seed/nexus/100/100', category: 'Security' },
  { id: '3', sender: 'Abyssal Voyager', subject: 'Weekly Expedition Log', preview: 'Log 402: Visibility improved near the hydrothermal vents. Structural anomalies in the lower tiers detected.', time: 'Yesterday', read: true, starred: false, avatar: 'https://picsum.photos/seed/voyage/100/100', category: 'Logs' },
  { id: '4', sender: 'Nova Research Group', subject: 'Observation of Pulsar Alpha-9', preview: 'The spectral data gathered from the last transit suggests a core collapse is imminent. Gamma-ray activity surging.', time: 'Just Now', read: false, starred: true, avatar: 'https://picsum.photos/seed/nova/100/100', category: 'Science' },
  { id: '5', sender: 'Deep Space Logistics', subject: 'Manifest: Dyson Swarm Parts', preview: 'Your shipment of 5,000 mirrors has cleared the asteroid belt and is expected at the docking bay shortly.', time: '2 days ago', read: true, starred: false, avatar: 'https://picsum.photos/seed/space/100/100', category: 'Admin' },
  { id: '6', sender: 'Event Horizon', subject: 'Stability Protocol Update', preview: 'The Aether core suggests a 12% increase in signal coherence. Recalibration scheduled for 0400 UTC.', time: '4 hours ago', read: false, starred: false, avatar: 'https://picsum.photos/seed/horizon/100/100', category: 'System' }
];

export const EmailView = ({ refreshTrigger = 0, layout = 'curated', experience = 'ink' }: { refreshTrigger?: number; layout?: LayoutType; experience?: ExperienceType }) => {
  const [emails, setEmails] = useState<Email[]>(DEMO_EMAILS);
  const [selectedEmail, setSelectedEmail] = useState<Email | null>(DEMO_EMAILS[0]);
  const [isComposing, setIsComposing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const fetchEmails = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/gmail/list');
      if (response.status === 404) return;
      if (!response.ok) throw new Error('Failed to fetch emails');
      const data = await response.json();
      if (Array.isArray(data)) {
        setEmails(data);
        if (data.length > 0 && !selectedEmail) {
          setSelectedEmail(data[0]);
        }
      } else {
        console.warn('API did not return an array:', data);
        // Stick with demo data if API fails to return array
      }
    } catch (error) {
      console.error('Fetch error:', error);
      toast.error('Could not refresh letter box.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (refreshTrigger > 0) fetchEmails();
  }, [refreshTrigger]);

  // Handle Vision Rendering
  if (experience === 'ocean') return <OceanVision emails={emails} selectedEmail={selectedEmail} setSelectedEmail={setSelectedEmail} />;
  if (experience === 'abyss') return <AbyssVision emails={emails} selectedEmail={selectedEmail} setSelectedEmail={setSelectedEmail} />;
  if (experience === 'planetary' || experience === 'nebula') return <SpaceVision emails={emails} selectedEmail={selectedEmail} setSelectedEmail={setSelectedEmail} type={experience} />;
  if (experience === 'prism') return <PrismVision emails={emails} selectedEmail={selectedEmail} setSelectedEmail={setSelectedEmail} />;

  return (
    <div className={`flex-1 flex overflow-hidden ${layout === 'classic' ? 'flex-col' : ''}`}>
      {/* Email List */}
      <AnimatePresence>
        {(layout !== 'solo' || !selectedEmail) && (
          <motion.div 
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: layout === 'classic' ? '100%' : '384px', opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            className={`border-r border-white/5 flex flex-col overflow-hidden shrink-0 transition-all duration-700 ${layout === 'classic' ? 'h-1/3 border-b border-r-0' : 'h-full'}`}
          >
            <div className="p-6 flex items-center justify-between border-b border-white/5 bg-white/[0.02]">
              <div className="flex items-center gap-4">
                <h2 className="serif text-xl opacity-80 uppercase tracking-widest text-[11px] font-bold">Mailbox</h2>
                <button 
                  onClick={fetchEmails} 
                  disabled={isLoading}
                  className={`p-2 hover:bg-white/5 rounded-full transition-all ${isLoading ? 'animate-spin opacity-50' : ''}`}
                >
                  <RefreshCw size={12} className="text-white/40" />
                </button>
              </div>
              <button 
                onClick={() => setIsComposing(true)}
                className="w-8 h-8 bg-accent rounded-full flex items-center justify-center hover:scale-110 active:scale-95 transition-all shadow-lg shadow-accent/20"
              >
                <PenLine className="w-4 h-4 text-white" />
              </button>
            </div>
            
            <div className={`flex-1 overflow-y-auto pb-8 ${layout === 'classic' ? 'flex overflow-x-auto gap-4 p-4 pb-4' : ''}`}>
              {isLoading && emails.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-48 text-white/20 gap-4 w-full">
                  <Loader2 className="w-8 h-8 animate-spin" />
                  <p className="text-[10px] uppercase tracking-widest">Calling the Post Man...</p>
                </div>
              ) : emails.length > 0 ? (
                emails.map((email) => (
                  <EmailItem 
                    key={email.id} 
                    email={email} 
                    active={selectedEmail?.id === email.id} 
                    layout={layout}
                    onClick={() => setSelectedEmail(email)} 
                  />
                ))
              ) : (
                <div className="p-10 text-center w-full">
                  <div className="mb-4 text-white/5 flex justify-center">
                    <Mail size={48} strokeWidth={1} />
                  </div>
                  <p className="text-muted text-sm serif-italic text-white/40">Your letter box is waiting to be filled.</p>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Reader */}
      <div className="flex-1 flex flex-col bg-white/[0.01] relative overflow-hidden">
        {selectedEmail ? (
          <AnimatePresence mode="wait">
            <motion.div 
              key={selectedEmail.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex-1 flex flex-col p-10 overflow-hidden"
            >
              {layout === 'solo' && (
                <button 
                  onClick={() => setSelectedEmail(null)}
                  className="absolute top-6 left-6 p-3 bg-white/5 rounded-full hover:bg-white/10 transition-all z-10"
                >
                  <ChevronRight className="w-4 h-4 rotate-180" />
                </button>
              )}
              
              <div className="flex items-center justify-between mb-12 border-b border-white/5 pb-8">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full border border-white/20 overflow-hidden bg-accent/10">
                    <img src={selectedEmail.avatar} className="w-full h-full object-cover" alt="" referrerPolicy="no-referrer" />
                  </div>
                  <div>
                    <div className="text-[10px] uppercase tracking-widest text-muted mb-1 font-bold">Sender</div>
                    <h3 className="serif-italic text-2xl leading-none">{selectedEmail.sender}</h3>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button className="glass-button !px-3"><Star className={`w-4 h-4 ${selectedEmail.starred ? 'fill-accent text-accent' : 'text-white/40'}`} /></button>
                  <button className="glass-button !px-10 hidden sm:flex items-center gap-2 flex-shrink-0">Reply</button>
                </div>
              </div>

              <h2 className="display text-5xl mb-8 leading-tight">{selectedEmail.subject}</h2>
              
              <div className="flex-1 text-white/80 leading-relaxed text-lg font-light space-y-8 overflow-y-auto pr-4 serif-italic selection:bg-accent/30 font-serif">
                <div dangerouslySetInnerHTML={{ __html: selectedEmail.preview }} className="whitespace-pre-wrap typography-content" />
              </div>

              <div className="mt-8 pt-8 border-t border-white/5 flex gap-4">
                <button className="glass-button flex-1 flex items-center justify-center gap-2 font-bold p-6 bg-accent/5 hover:bg-accent/10 border-accent/20">
                  <Reply className="w-4 h-4" /> Reply
                </button>
                <button className="glass-button flex-1 flex items-center justify-center gap-2 font-bold p-6">
                  <Forward className="w-4 h-4" /> Forward
                </button>
              </div>
            </motion.div>
          </AnimatePresence>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-white/10">
            <Mail className="w-16 h-16 mb-4 opacity-10" strokeWidth={1} />
            <p className="serif-italic text-xl tracking-wide opacity-20">Select a letter to read</p>
          </div>
        )}
      </div>

      {/* Composer Modal */}
      <AnimatePresence>
        {isComposing && (
          <Composer onClose={() => setIsComposing(false)} />
        )}
      </AnimatePresence>
    </div>
  );
};

// --- Experiences ---

const OceanVision = ({ emails, selectedEmail, setSelectedEmail }: any) => (
  <div className="flex-1 flex gap-6 p-8 overflow-hidden bg-[radial-gradient(circle_at_50%_50%,#0d1515_0%,#080f10_100%)]">
    <div className="flex-1 flex flex-col space-y-4 overflow-y-auto pr-2">
      <div className="flex justify-between items-center mb-2">
        <h2 className="font-h2 text-cyan-100 text-2xl font-bold tracking-tighter">Incoming Signals</h2>
        <span className="px-3 py-1 organic-radius text-[10px] bg-cyan-500/20 text-cyan-400 font-bold uppercase tracking-widest">3 New</span>
      </div>
      {emails.map((e: any) => (
        <motion.div 
          key={e.id}
          onClick={() => setSelectedEmail(e)}
          className={`glass-panel organic-radius p-6 border-l-4 transition-all cursor-pointer ${selectedEmail?.id === e.id ? 'border-primary bioluminescent-glow-cyan bg-white/5' : 'border-white/10 opacity-70 hover:opacity-100'}`}
        >
          <div className="flex items-center justify-between mb-4">
            <span className="text-[10px] uppercase tracking-widest text-cyan-400 font-bold">{e.sender}</span>
            <span className="text-xs text-slate-500">{e.time}</span>
          </div>
          <h3 className="font-h2 text-xl text-cyan-50 mb-2 truncate font-bold">{e.subject}</h3>
          <p className="text-slate-400 text-sm line-clamp-2">{e.preview}</p>
        </motion.div>
      ))}
    </div>
    
    <div className="hidden lg:flex flex-[1.5] glass-panel organic-radius overflow-hidden flex-col border-white/10">
      <AnimatePresence mode="wait">
        {selectedEmail ? (
          <motion.div 
            key={selectedEmail.id}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex-1 flex flex-col pt-10"
          >
            <div className="px-10 pb-8 border-b border-white/5">
              <div className="flex items-center gap-4 mb-4">
                <img src={selectedEmail.avatar} className="w-12 h-12 rounded-full border border-primary/50" alt="" />
                <div>
                  <h2 className="font-h2 text-2xl text-cyan-50 font-bold">{selectedEmail.subject}</h2>
                  <p className="text-[10px] text-cyan-400 uppercase tracking-widest">{selectedEmail.sender}</p>
                </div>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-10 text-slate-300 leading-relaxed text-lg font-light">
              <div dangerouslySetInnerHTML={{ __html: selectedEmail.preview }} className="whitespace-pre-wrap" />
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </div>
  </div>
);

const AbyssVision = ({ emails, selectedEmail, setSelectedEmail }: any) => (
  <div className="flex-1 depth-gradient overflow-y-auto relative py-20 px-4 flex flex-col items-center gap-24">
    <div className="fixed right-10 top-1/2 -translate-y-1/2 flex flex-col items-center gap-4">
      <div className="h-64 w-px bg-cyan-400/20 relative">
        <div className="absolute top-1/4 h-20 w-px bg-cyan-400 shadow-[0_0_10px_#00F0FF]" />
      </div>
      <span className="text-[10px] font-bold text-cyan-400 rotate-90 mt-8">240M</span>
    </div>

    <div className="w-full max-w-2xl space-y-32">
      {emails.map((e: any, idx: number) => (
        <motion.div 
          key={e.id}
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className={`glass-pod p-10 rounded-[40px_100px_40px_100px] border-white/10 relative transition-transform hover:scale-[1.02] cursor-pointer ${idx % 2 === 0 ? 'ml-0' : 'mr-0'}`}
        >
          <div className="flex gap-6 items-start">
            <img src={e.avatar} className="w-16 h-16 rounded-full border-2 border-cyan-400/20" alt="" />
            <div className="flex-1">
              <div className="flex justify-between items-center mb-4">
                <span className="text-[10px] uppercase tracking-widest text-cyan-400">{e.sender}</span>
                <span className="text-[10px] text-slate-500 font-mono">DEPTH: {idx * 150}M</span>
              </div>
              <h3 className="text-2xl font-bold mb-4">{e.subject}</h3>
              <p className="text-slate-400 text-sm line-clamp-3">{e.preview}</p>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  </div>
);

const SpaceVision = ({ emails, selectedEmail, setSelectedEmail, type }: any) => (
  <div className="flex-1 bg-[#0d1515] relative overflow-hidden flex items-center justify-center p-12">
    <div className="absolute inset-0 opacity-20 pointer-events-none">
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-400/20 blur-[100px] rounded-full" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-400/20 blur-[100px] rounded-full" />
    </div>

    {type === 'planetary' && (
      <div className="relative w-full h-full flex items-center justify-center">
        <div className="w-24 h-24 rounded-full sun-glow flex items-center justify-center animate-pulse z-10">
          <Zap className="text-white" />
        </div>
        
        <div className="orbit-path w-[300px] h-[300px]" />
        <div className="orbit-path w-[500px] h-[500px]" />
        
        {emails.slice(0, 4).map((e: any, i: number) => {
          const angle = (i * 90) * (Math.PI / 180);
          const x = Math.cos(angle) * (150 + i * 25);
          const y = Math.sin(angle) * (150 + i * 25);
          return (
            <motion.div
              key={e.id}
              onClick={() => setSelectedEmail(e)}
              initial={{ x: 0, y: 0 }}
              animate={{ x, y }}
              className="absolute w-12 h-12 bg-white/5 border border-white/10 rounded-full flex items-center justify-center cursor-pointer hover:bg-cyan-400 hover:scale-125 transition-all"
            >
              <Mail size={16} />
              <div className="absolute top-full mt-2 text-[8px] uppercase tracking-widest whitespace-nowrap opacity-40">{e.sender}</div>
            </motion.div>
          );
        })}

        <AnimatePresence>
          {selectedEmail && (
            <motion.div 
               initial={{ opacity: 0, scale: 0.9 }}
               animate={{ opacity: 1, scale: 1 }}
               className="absolute z-50 w-[500px] glass-panel p-8 shadow-2xl border-white/10"
            >
              <div className="flex items-center gap-4 mb-6">
                <img src={selectedEmail.avatar} className="w-10 h-10 rounded-full border border-cyan-400/30" alt="" />
                <h3 className="font-bold text-primary">{selectedEmail.subject}</h3>
              </div>
              <p className="text-slate-400 text-sm leading-relaxed">{selectedEmail.preview}</p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    )}

    {type === 'nebula' && (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 w-full max-w-6xl z-10 overflow-y-auto">
        {emails.map((e: any) => (
          <div 
            key={e.id} 
            onClick={() => setSelectedEmail(e)}
            className="glass-panel p-6 border-white/5 bg-gradient-to-br from-white/[0.03] to-transparent hover:border-cyan-400/30 transition-all group cursor-pointer"
          >
             <h3 className="font-bold text-lg mb-2 group-hover:text-cyan-400 transition-colors uppercase tracking-widest text-[11px]">{e.subject}</h3>
             <p className="text-slate-400 text-xs line-clamp-4 leading-relaxed">{e.preview}</p>
          </div>
        ))}
      </div>
    )}
  </div>
);

const PrismVision = ({ emails, selectedEmail, setSelectedEmail }: any) => (
  <div className="flex-1 relative perspective-container flex items-center justify-center pt-24 pl-12 pr-12 pb-12 overflow-hidden bg-[#0d1515]">
    <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')]" />
    
    <div className="absolute glass-panel w-[500px] h-[350px] top-40 left-[25%] -translate-x-1/2 -rotate-12 opacity-30 blur-[2px] transition-all duration-700 hover:rotate-0 hover:opacity-100 z-10" />
    
    <div className="relative glass-panel prism-active w-[700px] max-w-full min-h-[500px] rounded-[40px] z-30 transition-all duration-700 hover:transform-none group p-10 flex flex-col scale-110">
      {selectedEmail ? (
        <>
          <div className="flex justify-between items-start mb-10">
            <div className="flex items-center gap-5">
              <img src={selectedEmail.avatar} className="w-16 h-16 rounded-full border-2 border-primary/30" alt="" />
              <div>
                <h3 className="font-h1 text-2xl mb-1 tracking-tight text-cyan-400 font-bold uppercase">{selectedEmail.sender}</h3>
                <p className="text-[10px] text-white/40 uppercase tracking-[3px]">Transmission Channel</p>
              </div>
            </div>
          </div>
          <div className="flex-grow space-y-6">
            <h1 className="text-4xl leading-[1.1] font-bold text-white mb-8">{selectedEmail.subject}</h1>
            <div className="text-slate-300 leading-relaxed text-lg" dangerouslySetInnerHTML={{ __html: selectedEmail.preview }} />
          </div>
        </>
      ) : (
        <div className="flex-1 flex items-center justify-center text-white/20 uppercase tracking-[5px] text-xl font-bold">
           Station Idle
        </div>
      )}
    </div>

    <div className="absolute bottom-10 right-10 flex flex-col gap-4 z-40 max-w-xs">
       {emails.slice(0,3).map((e: any) => (
         <div 
           key={e.id}
           onClick={() => setSelectedEmail(e)}
           className="glass-panel p-4 rotate-6 hover:rotate-0 transition-all cursor-pointer border-white/5 opacity-50 hover:opacity-100"
         >
           <h4 className="text-[10px] font-bold uppercase text-cyan-400 mb-2">{e.sender}</h4>
           <p className="text-[10px] text-white/60 truncate">{e.subject}</p>
         </div>
       ))}
    </div>
  </div>
);

// --- Subcomponents ---

const EmailItem = ({ email, active, onClick, layout }: { email: Email; active: boolean; onClick: () => void, layout: string }) => (
  <button 
    onClick={onClick}
    className={`text-left p-6 transition-all relative overflow-hidden group border-b border-white/5 shrink-0 ${active ? 'bg-accent/5' : 'hover:bg-white/[0.01]'} ${layout === 'classic' ? 'min-w-[300px] border-b-0 border-r rounded-xl' : 'w-full'}`}
  >
    <div className="flex justify-between mb-2">
      <span className={`text-[9px] uppercase tracking-[2px] font-bold ${active ? 'text-accent' : 'text-white/30'}`}>
        {!email.read ? 'Draft' : 'Received'}
      </span>
      <span className="text-[10px] text-white/20 tabular-nums truncate ml-2 font-mono uppercase">{email.time}</span>
    </div>
    <h4 className={`serif-italic text-lg leading-tight mb-1 truncate ${!email.read && 'font-bold opacity-100'} ${active ? 'opacity-100' : 'opacity-80 group-hover:opacity-100'}`}>{email.subject}</h4>
    <div className="text-[10px] uppercase tracking-widest text-muted truncate">{email.sender}</div>
    
    {active && (
      <motion.div 
        layoutId="active-line" 
        className="absolute left-0 top-0 bottom-0 w-0.5 bg-accent shadow-[0_0_15px_rgba(var(--theme-accent-rgb),0.4)]" 
      />
    )}
  </button>
);

const Composer = ({ onClose }: { onClose: () => void }) => {
  const [isPolishing, setIsPolishing] = useState(false);
  const editor = useEditor({
    extensions: [
      StarterKit,
      Link.configure({ openOnClick: false }),
      Underline,
    ],
    content: '<p>Start drafting your message...</p>',
    editorProps: {
      attributes: {
        class: 'prose prose-invert focus:outline-none max-w-none text-white/80 min-h-[300px]',
      },
    },
  });

  const polishEmail = async () => {
    if (!editor || isPolishing) return;
    setIsPolishing(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const prompt = `Rewrite the following email to be more professional, elegant, and "incredibly beautiful". Keep the core meaning but elevate the prose. Output ONLY the polished HTML body (no markdown code blocks, just the HTML):\n\n${editor.getHTML()}`;
      
      const response = await ai.models.generateContent({
        model: "gemini-1.5-flash",
        contents: prompt,
      });
      
      const polishedText = response.text;
      if (polishedText) {
        editor.commands.setContent(polishedText);
      }
    } catch (error) {
      console.error('Gemini error:', error);
    } finally {
      setIsPolishing(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div 
        initial={{ scale: 0.9, y: 50 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 50 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-4xl glass-panel shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        <div className="p-6 border-b border-white/5 flex items-center justify-between bg-white/[0.02]">
          <h2 className="font-serif text-2xl font-bold flex items-center gap-3">
            <PenLine className="w-6 h-6 text-accent" />
            New Message
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-all">
            <X className="w-5 h-5 text-white/40" />
          </button>
        </div>

        <div className="px-8 py-6 space-y-4">
          <div className="flex items-center gap-4 border-b border-white/5 py-2">
            <span className="text-white/30 text-sm w-12 font-medium">To:</span>
            <input type="text" className="bg-transparent text-sm w-full focus:outline-none" placeholder="Recipients" />
          </div>
          <div className="flex items-center gap-4 border-b border-white/5 py-2">
            <span className="text-white/30 text-sm w-12 font-medium">Subject:</span>
            <input type="text" className="bg-transparent text-sm w-full focus:outline-none font-bold" placeholder="Subject" />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-8 py-4">
          <div className="flex gap-2 mb-4">
             <button 
               onClick={polishEmail}
               disabled={isPolishing}
               className="text-xs font-bold flex items-center gap-2 px-4 py-2 rounded-full bg-accent/20 border border-accent/30 hover:bg-accent/30 transition-all disabled:opacity-50"
             >
               {isPolishing ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3 text-accent" />}
               <span>Magic Polish</span>
             </button>
          </div>
          <div className="p-6 bg-white/[0.01] rounded-2xl border border-white/5 min-h-[400px]">
            <EditorContent editor={editor} />
          </div>
        </div>

        <div className="p-6 border-t border-white/5 flex items-center justify-between bg-white/[0.02]">
          <div className="flex gap-2">
            <button className="p-2 hover:bg-white/10 rounded-lg transition-all text-white/40"><Paperclip className="w-5 h-5" /></button>
          </div>
          <button className="bg-accent hover:bg-accent/90 px-8 py-2.5 rounded-full font-bold flex items-center gap-2 shadow-lg shadow-accent/20 active:scale-95 transition-all">
            <Send className="w-4 h-4" /> Send
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
};
