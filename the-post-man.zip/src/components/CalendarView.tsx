import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight, Plus, MapPin, Clock, Users, Sparkles } from 'lucide-react';
import { format, addMonths, subMonths, startOfMonth, endOfMonth, startOfWeek, endOfWeek, isSameMonth, isSameDay, addDays, eachDayOfInterval } from 'date-fns';

type Event = {
  id: string;
  title: string;
  time: string;
  location: string;
  color: string;
  date: Date;
};

const MOCK_EVENTS: Event[] = [
  { id: '1', title: 'Museum Expansion Review', time: '10:00 AM', location: 'Design Studio', color: 'bg-accent', date: new Date() },
  { id: '2', title: 'Lunch with Elena', time: '1:00 PM', location: 'The Bistro', color: 'bg-emerald-500', date: new Date() },
  { id: '3', title: 'Marketing Brief', time: '3:30 PM', location: 'Main Conf Hall', color: 'bg-amber-500', date: addDays(new Date(), 2) },
];

export const CalendarView = () => {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const prevMonth = () => setCurrentMonth(subMonths(currentMonth, 1));
  const nextMonth = () => setCurrentMonth(addMonths(currentMonth, 1));

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(monthStart);
  const startDate = startOfWeek(monthStart);
  const endDate = endOfWeek(monthEnd);

  const calendarDays = eachDayOfInterval({
    start: startDate,
    end: endDate,
  });

  return (
    <div className="flex-1 flex flex-col overflow-hidden p-10">
      {/* Calendar Header */}
      <div className="flex items-center justify-between mb-12">
        <div className="flex items-center gap-8">
          <h2 className="display text-6xl">
            {format(currentMonth, 'MMMM')} <span className="serif-italic text-accent">{format(currentMonth, 'yyyy')}</span>
          </h2>
          <div className="flex gap-4">
            <button onClick={prevMonth} className="hover:text-accent transition-colors"><ChevronLeft size={24} /></button>
            <button onClick={nextMonth} className="hover:text-accent transition-colors"><ChevronRight size={24} /></button>
          </div>
        </div>
        <button className="glass-button">
          New Event
        </button>
      </div>

      <div className="grid grid-cols-7 mb-6">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
          <div key={day} className="text-center text-[10px] uppercase font-bold tracking-[0.3em] text-muted">{day}</div>
        ))}
      </div>

      <div className="flex-1 grid grid-cols-7 grid-rows-6 border border-white/8 rounded-[32px] overflow-hidden">
        {calendarDays.map((day, idx) => {
          const dayEvents = MOCK_EVENTS.filter(e => isSameDay(e.date, day));
          const isCurrentMonth = isSameMonth(day, monthStart);
          const isToday = isSameDay(day, new Date());

          return (
            <div 
              key={day.toString()} 
              className={`border border-white/5 relative p-6 transition-all hover:bg-white/[0.02] ${!isCurrentMonth ? 'opacity-10' : ''}`}
            >
              <span className={`serif text-xl ${isToday ? 'text-accent font-bold' : 'text-white/40'}`}>
                {format(day, 'd')}
              </span>
              
              <div className="mt-4 space-y-2">
                {dayEvents.map(event => (
                  <div key={event.id} className="group relative">
                    <div className="text-[10px] leading-tight font-light truncate text-white/80 group-hover:text-accent cursor-pointer transition-colors">
                      {event.time} — {event.title}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
