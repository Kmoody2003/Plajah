import React, { useState } from 'react';
import { motion, AnimatePresence, Reorder } from 'framer-motion';
import { Plus, Trash2, GripVertical, Palette, Search, Mic, Play, Pause, Volume2 } from 'lucide-react';
import { toast } from 'sonner';
import { VoiceCapture } from './VoiceCapture';

type Note = {
  id: string;
  content: string;
  color: string;
  x: number;
  y: number;
  audioUrl?: string;
};

const COLORS = [
  'bg-yellow-200 text-yellow-900',
  'bg-cyan-200 text-cyan-900',
  'bg-pink-200 text-pink-900',
  'bg-purple-200 text-purple-900',
  'bg-emerald-200 text-emerald-900',
  'bg-orange-200 text-orange-900'
];

export const StickyNotes = () => {
  const [notes, setNotes] = useState<Note[]>([
    { id: '1', content: 'Buy more stardust for the nebula drive', color: COLORS[0], x: 100, y: 100 },
    { id: '2', content: 'Call Event Horizon re: signal drift', color: COLORS[1], x: 400, y: 150 },
    { id: '3', content: 'Design new prism layout for the weekend', color: COLORS[2], x: 200, y: 400 },
  ]);

  const addNote = () => {
    const newNote: Note = {
      id: Date.now().toString(),
      content: '',
      color: COLORS[Math.floor(Math.random() * COLORS.length)],
      x: 50 + Math.random() * 200,
      y: 50 + Math.random() * 200
    };
    setNotes([...notes, newNote]);
  };

  const updateNote = (id: string, content: string) => {
    setNotes(notes.map(n => n.id === id ? { ...n, content } : n));
  };

  const deleteNote = (id: string) => {
    setNotes(notes.filter(n => n.id !== id));
    toast.info("Note discarded.");
  };

  return (
    <div className="flex-1 w-full h-full relative overflow-hidden bg-white/[0.02] p-8">
      {/* Background Grid */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none" 
           style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '30px 30px' }} 
      />

      <header className="absolute top-8 left-8 right-8 z-50 flex items-center justify-between pointer-events-none">
        <h2 className="text-3xl font-bold tracking-tight pointer-events-auto">Sticky Station</h2>
        <div className="flex gap-4 pointer-events-auto items-center">
          <VoiceCapture 
            compact 
            onTranscribe={(text, url) => {
              const newNote: Note = {
                id: Date.now().toString(),
                content: text,
                color: COLORS[Math.floor(Math.random() * COLORS.length)],
                x: 100 + Math.random() * 200,
                y: 100 + Math.random() * 200,
                audioUrl: url
              };
              setNotes([...notes, newNote]);
            }} 
            className="!w-12 !h-12 bg-white/10 hover:bg-white/20 border border-white/10"
          />
          <button 
            onClick={addNote}
            className="bg-accent text-white px-8 py-3 rounded-full font-bold shadow-xl shadow-accent/20 hover:scale-105 active:scale-95 transition-all"
          >
            + Drop Note
          </button>
        </div>
      </header>

      <div className="w-full h-full relative overflow-auto pt-24 custom-scrollbar">
        <AnimatePresence>
          {notes.map((note) => (
            <motion.div
              key={note.id}
              drag
              dragMomentum={false}
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              className={`absolute w-64 min-h-64 p-6 rounded-3xl shadow-2xl flex flex-col group cursor-grab active:cursor-grabbing ${note.color}`}
              style={{ left: note.x, top: note.y }}
            >
              <div className="flex items-center justify-between mb-4 opacity-0 group-hover:opacity-100 transition-opacity">
                 <GripVertical size={14} className="opacity-40" />
                 <button 
                   onClick={() => deleteNote(note.id)}
                   className="p-1.5 hover:bg-black/10 rounded-full transition-all"
                 >
                   <Trash2 size={14} />
                 </button>
              </div>
              <textarea 
                className="flex-1 bg-transparent border-none focus:ring-0 p-0 text-lg font-medium leading-tight resize-none placeholder:text-black/20"
                placeholder="What's floating in your mind?"
                value={note.content}
                onChange={(e) => updateNote(note.id, e.target.value)}
              />
              {note.audioUrl && (
                <div className="mt-2 flex items-center gap-3 p-3 bg-black/5 rounded-2xl border border-black/5">
                   <div className="w-8 h-8 rounded-full bg-black/10 flex items-center justify-center">
                      <Volume2 size={14} className="opacity-40" />
                   </div>
                   <audio src={note.audioUrl} controls className="h-8 max-w-[140px] [&::-webkit-media-controls-play-button]:bg-accent [&::-webkit-media-controls-panel]:bg-transparent" />
                </div>
              )}
              <div className="mt-4 flex justify-between items-center opacity-40 group-hover:opacity-100 transition-opacity">
                 <span className="text-[10px] font-bold uppercase tracking-widest">{new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric' }).format(new Date())}</span>
                 <Palette size={12} />
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
};
