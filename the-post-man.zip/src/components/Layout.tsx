import React, { useState, useEffect } from 'react';
import { Mail, Calendar, Layout as LayoutIcon, Settings, PenLine, Search, Bell, User, Plus, Trash2, Send, Paperclip, Sparkles, LogOut, ChevronRight, X, Palette, Columns, ChevronDown, Rocket, Waves as AbyssIcon, Cloud, Globe, Box, BookOpen } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import type { ThemeType, LayoutType, ExperienceType } from '../App';

// --- Types ---
type Tab = 'mail' | 'calendar' | 'board' | 'editor' | 'journal' | 'sticky';
type Account = { id: string; type: 'gmail' | 'outlook'; email: string; avatar: string };

// --- Components ---

const Sidebar = ({ 
  activeTab, 
  setActiveTab, 
  accounts, 
  onConnect,
  theme,
  setTheme,
  layout,
  setLayout,
  experience,
  setExperience,
  onOpenSettings
}: { 
  activeTab: Tab; 
  setActiveTab: (t: Tab) => void;
  accounts: Account[];
  onConnect: (type: 'google' | 'microsoft') => void;
  theme: ThemeType;
  setTheme: (t: ThemeType) => void;
  layout: LayoutType;
  setLayout: (l: LayoutType) => void;
  experience: ExperienceType;
  setExperience: (e: ExperienceType) => void;
  onOpenSettings: () => void;
}) => {
  const themes: {id: ThemeType, color: string, label: string}[] = [
    { id: 'editorial', color: '#fb7185', label: 'Ink' },
    { id: 'plajah', color: '#0ea5e9', label: 'Plajah' },
    { id: 'focus', color: '#000000', label: 'Void' },
    { id: 'brutalist', color: '#00ff00', label: 'Brute' }
  ];

  return (
    <aside className={`w-16 flex flex-col items-center py-6 gap-8 glass-panel border-white/12 transition-all duration-700 ${theme === 'focus' ? 'opacity-0 hover:opacity-100' : ''}`}>
      <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-accent/80 to-accent flex items-center justify-center font-bold text-white shadow-lg shadow-accent/20">
        P
      </div>
      
      <nav className="flex flex-col gap-8 mt-12">
        <SidebarLink icon={<Mail size={22} />} active={activeTab === 'mail'} onClick={() => setActiveTab('mail')} title="Letters" />
        <SidebarLink icon={<Calendar size={22} />} active={activeTab === 'calendar'} onClick={() => setActiveTab('calendar')} title="Schedule" />
        <SidebarLink icon={<PenLine size={22} />} active={activeTab === 'editor'} onClick={() => setActiveTab('editor')} title="Processor" />
        <SidebarLink icon={<BookOpen size={22} />} active={activeTab === 'journal'} onClick={() => setActiveTab('journal')} title="Journal" />
        <SidebarLink icon={<Sparkles size={22} />} active={activeTab === 'sticky'} onClick={() => setActiveTab('sticky')} title="Sticky Notes" />
        <SidebarLink icon={<LayoutIcon size={22} />} active={activeTab === 'board'} onClick={() => setActiveTab('board')} title="Ideas" />
      </nav>

      <div className="mt-auto flex flex-col gap-6 mb-4 items-center">
        <button 
           onClick={onOpenSettings}
           className="p-2 text-white/40 hover:text-white hover:bg-white/5 rounded-full transition-all"
           title="Settings"
        >
          <Settings size={20} />
        </button>

        <div className="flex flex-col gap-2 p-1 bg-white/5 rounded-full border border-white/5">
          <button 
            onClick={() => setLayout('curated')} 
            className={`p-2 rounded-full transition-all ${layout === 'curated' ? 'bg-accent text-white' : 'text-white/40 hover:text-white'}`}
            title="Curated View"
          >
            <Columns size={12} />
          </button>
          <button 
            onClick={() => setLayout('classic')} 
            className={`p-2 rounded-full transition-all ${layout === 'classic' ? 'bg-accent text-white' : 'text-white/40 hover:text-white'}`}
            title="Classic View"
          >
            <LayoutIcon size={12} />
          </button>
          <button 
            onClick={() => setLayout('solo')} 
            className={`p-2 rounded-full transition-all ${layout === 'solo' ? 'bg-accent text-white' : 'text-white/40 hover:text-white'}`}
            title="Reader Focus"
          >
            <PenLine size={12} />
          </button>
        </div>

        <div className="flex flex-col gap-2">
          {themes.map(t => (
            <button
              key={t.id}
              onClick={() => setTheme(t.id)}
              className={`w-3 h-3 rounded-full transition-all border ${theme === t.id ? 'scale-150 border-white' : 'border-transparent opacity-40 hover:opacity-100'}`}
              style={{ backgroundColor: t.color }}
              title={t.label}
            />
          ))}
        </div>

        <div className="flex flex-col gap-4">
          {accounts.map(acc => (
            <div key={acc.id} className="w-8 h-8 rounded-full border border-white/20 overflow-hidden flex items-center justify-center text-[10px] group cursor-pointer transition-all hover:border-accent">
              <img src={acc.avatar} alt={acc.email} className="w-full h-full object-cover" />
            </div>
          ))}
          <button 
            onClick={() => onConnect('google')}
            className="w-8 h-8 rounded-full border border-dashed border-white/20 flex items-center justify-center text-white/40 hover:text-white hover:border-white/40 transition-all"
          >
            <Plus size={14} />
          </button>
        </div>
      </div>
    </aside>
  );
};

const SidebarLink = ({ icon, active, onClick, title }: { icon: React.ReactNode; active: boolean; onClick: () => void, title?: string }) => (
  <button 
    onClick={onClick}
    className={`transition-all hover:scale-110 active:scale-95 ${active ? 'text-accent opacity-100' : 'text-white opacity-40 hover:opacity-100'}`}
    title={title}
  >
    {icon}
  </button>
);

const Header = ({ 
  title, 
  theme,
  experience,
  setExperience
}: { 
  title: string;
  theme: ThemeType;
  experience: ExperienceType;
  setExperience: (e: ExperienceType) => void;
}) => {
  const [showVisions, setShowVisions] = useState(false);

  const visions: {id: ExperienceType, label: string, icon: React.ReactNode}[] = [
    { id: 'ink', label: 'Original Ink', icon: <PenLine size={14} /> },
    { id: 'ocean', label: 'Deep Ocean', icon: <Box size={14} /> },
    { id: 'abyss', label: 'Abyssal Depth', icon: <AbyssIcon size={14} /> },
    { id: 'nebula', label: 'Nebula Space', icon: <Cloud size={14} /> },
    { id: 'planetary', label: 'Planetary System', icon: <Rocket size={14} /> },
    { id: 'prism', label: 'Floating Prism', icon: <Globe size={14} /> },
  ];

  return (
    <header className={`flex justify-between items-end pb-6 mt-2 transition-all duration-700 ${theme === 'focus' ? 'px-10' : ''}`}>
      <div className="flex items-end gap-8">
        <h1 className="display text-6xl">
           <span className="serif-italic">{title}</span>
        </h1>

        <div className="relative mb-2">
          <button 
            onClick={() => setShowVisions(!showVisions)}
            className="flex items-center gap-2 px-4 py-1.5 glass-panel rounded-full text-[10px] uppercase tracking-widest text-muted hover:text-white transition-colors"
          >
            Vision: <span className="text-accent font-bold">{experience}</span>
            <ChevronDown size={10} className={`transition-transform duration-300 ${showVisions ? 'rotate-180' : ''}`} />
          </button>

          <AnimatePresence>
            {showVisions && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="absolute top-full left-0 mt-2 w-48 glass-panel p-2 z-[100] shadow-2xl overflow-hidden"
              >
                {visions.map(v => (
                  <button
                    key={v.id}
                    onClick={() => {
                      setExperience(v.id);
                      setShowVisions(false);
                    }}
                    className={`w-full text-left px-4 py-2 rounded-lg text-[10px] uppercase tracking-widest flex items-center gap-3 transition-all ${experience === v.id ? 'bg-accent/20 text-accent font-bold' : 'text-white/40 hover:bg-white/5 hover:text-white'}`}
                  >
                    {v.icon}
                    {v.label}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <div className="flex gap-4 items-center">
        <div className="glass-button">New Letter</div>
        <div className="text-sm text-muted">
          {new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', year: 'numeric' }).format(new Date())}
        </div>
      </div>
    </header>
  );
};

export { Sidebar, Header };
export type { Tab, Account };
