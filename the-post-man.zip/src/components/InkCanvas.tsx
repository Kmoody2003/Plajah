import React, { useState, useRef, useEffect } from 'react';
import { getStroke } from 'perfect-freehand';
import { motion } from 'framer-motion';
import { MousePointer2, Pencil, Square, Circle, Minus, Eraser, Download, Trash2, Undo } from 'lucide-react';

interface Point {
  x: number;
  y: number;
  pressure?: number;
}

interface Stroke {
  points: Point[];
  color: string;
  size: number;
  type: 'pen' | 'square' | 'circle' | 'line';
}

export const InkCanvas = () => {
  const [strokes, setStrokes] = useState<Stroke[]>([]);
  const [currentStroke, setCurrentStroke] = useState<Point[] | null>(null);
  const [color, setColor] = useState('#ffffff');
  const [size, setSize] = useState(3);
  const [tool, setTool] = useState<'pen' | 'square' | 'circle' | 'line' | 'eraser'>('pen');
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const getSvgPathFromStroke = (stroke: Point[]) => {
    if (!stroke.length) return "";
    const outlinePoints = getStroke(stroke, {
      size: size,
      thinning: 0.5,
      smoothing: 0.5,
      streamline: 0.5,
    });

    const pathData = outlinePoints.reduce(
      (acc, [x, y], i, arr) => {
        if (i === 0) acc.push(`M ${x} ${y}`);
        else if (i === arr.length - 1) acc.push(`L ${x} ${y} Z`);
        else acc.push(`L ${x} ${y}`);
        return acc;
      },
      [] as string[]
    );

    return pathData.join(" ");
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    // If it's a touch or pen, it supports pressure
    const isPen = e.pointerType === 'pen';
    const point: Point = { 
      x: e.nativeEvent.offsetX, 
      y: e.nativeEvent.offsetY,
      pressure: e.pressure 
    };

    if (tool === 'eraser') {
      // Basic eraser: clear strokes near the point
      setStrokes(prev => prev.filter(s => {
        const firstPoint = s.points[0];
        const dist = Math.sqrt(Math.pow(firstPoint.x - point.x, 2) + Math.pow(firstPoint.y - point.y, 2));
        return dist > 20;
      }));
      return;
    }

    setCurrentStroke([point]);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!currentStroke) return;

    const point: Point = { 
      x: e.nativeEvent.offsetX, 
      y: e.nativeEvent.offsetY,
      pressure: e.pressure 
    };

    if (tool === 'pen') {
      setCurrentStroke(prev => prev ? [...prev, point] : [point]);
    } else {
      // Shape tools: update the second point
      setCurrentStroke(prev => [prev![0], point]);
    }
  };

  const handlePointerUp = () => {
    if (!currentStroke) return;
    
    setStrokes(prev => [...prev, {
      points: currentStroke,
      color,
      size,
      type: tool as any
    }]);
    setCurrentStroke(null);
  };

  const renderShape = (stroke: Stroke, index: number) => {
    const { points, color, size, type } = stroke;
    if (points.length < 2 && type !== 'pen') return null;

    if (type === 'pen') {
      return (
        <path 
          key={index} 
          d={getSvgPathFromStroke(points)} 
          fill={color} 
        />
      );
    }

    const [start, end] = [points[0], points[points.length - 1]];
    const width = end.x - start.x;
    const height = end.y - start.y;

    if (type === 'square') {
      return (
        <rect 
          key={index}
          x={Math.min(start.x, end.x)}
          y={Math.min(start.y, end.y)}
          width={Math.abs(width)}
          height={Math.abs(height)}
          stroke={color}
          strokeWidth={size}
          fill="none"
        />
      );
    }

    if (type === 'circle') {
      const radius = Math.sqrt(Math.pow(width, 2) + Math.pow(height, 2)) / 2;
      return (
        <circle 
          key={index}
          cx={start.x + width / 2}
          cy={start.y + height / 2}
          r={radius}
          stroke={color}
          strokeWidth={size}
          fill="none"
        />
      );
    }

    if (type === 'line') {
      return (
        <line 
          key={index}
          x1={start.x}
          y1={start.y}
          x2={end.x}
          y2={end.y}
          stroke={color}
          strokeWidth={size}
          strokeLinecap="round"
        />
      );
    }

    return null;
  };

  return (
    <div className="flex-1 flex flex-col bg-[#0f1218] p-6 gap-6 h-full overflow-hidden">
      <div className="flex items-center justify-between glass-panel px-6 py-3 border-white/10 shrink-0">
        <div className="flex items-center gap-4">
           <div className="flex bg-white/5 p-1 rounded-xl gap-1">
             <ToolBtn active={tool === 'pen'} onClick={() => setTool('pen')} icon={<Pencil size={18} />} title="Ink Pen" />
             <ToolBtn active={tool === 'square'} onClick={() => setTool('square')} icon={<Square size={18} />} title="Rectangle" />
             <ToolBtn active={tool === 'circle'} onClick={() => setTool('circle')} icon={<Circle size={18} />} title="Circle" />
             <ToolBtn active={tool === 'line'} onClick={() => setTool('line')} icon={<Minus size={18} />} title="Line" />
             <ToolBtn active={tool === 'eraser'} onClick={() => setTool('eraser')} icon={<Eraser size={18} />} title="Eraser" />
           </div>

           <div className="h-6 w-px bg-white/10" />

           <div className="flex gap-2">
             {['#ffffff', '#ff4757', '#2ed573', '#1e90ff', '#eccc68'].map(c => (
               <button 
                 key={c}
                 onClick={() => setColor(c)}
                 className={`w-6 h-6 rounded-full border-2 transition-all ${color === c ? 'border-accent scale-110' : 'border-transparent'}`}
                 style={{ backgroundColor: c }}
               />
             ))}
           </div>

           <div className="h-6 w-px bg-white/10" />
           
           <input 
             type="range" 
             min="1" max="20" 
             value={size} 
             onChange={(e) => setSize(Number(e.target.value))}
             className="w-24 accent-accent"
           />
        </div>

        <div className="flex gap-3">
          <button 
            onClick={() => setStrokes(prev => prev.slice(0, -1))}
            className="p-2 hover:bg-white/5 rounded-lg text-white/40 hover:text-white transition-all"
            title="Undo"
          >
            <Undo size={18} />
          </button>
          <button 
            onClick={() => setStrokes([])}
            className="p-2 hover:bg-rose-500/10 rounded-lg text-rose-400 transition-all"
            title="Clear Canvas"
          >
            <Trash2 size={18} />
          </button>
        </div>
      </div>

      <div 
        ref={containerRef}
        className="flex-1 glass-panel border-white/5 relative overflow-hidden bg-black/20 touch-none active:cursor-crosshair"
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
      >
        <svg 
           className="w-full h-full pointer-events-none"
           viewBox={`0 0 ${containerRef.current?.clientWidth || 1000} ${containerRef.current?.clientHeight || 1000}`}
        >
          {strokes.map((s, i) => renderShape(s, i))}
          {currentStroke && renderShape({ points: currentStroke, color, size, type: tool as any }, -1)}
        </svg>

        {/* Support for palm rejection and high precision */}
        <div className="absolute bottom-4 right-4 text-[10px] uppercase tracking-widest text-muted flex items-center gap-2">
           <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
           Precision Inking Active
        </div>
      </div>
    </div>
  );
};

const ToolBtn = ({ active, onClick, icon, title }: any) => (
  <button 
    onClick={onClick}
    className={`p-2 rounded-lg transition-all ${active ? 'bg-accent text-white' : 'text-white/40 hover:text-white hover:bg-white/5'}`}
    title={title}
  >
    {icon}
  </button>
);
