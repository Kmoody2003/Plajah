import React, { useState } from 'react';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Link from '@tiptap/extension-link';
import Underline from '@tiptap/extension-underline';
import { motion, AnimatePresence } from 'framer-motion';
import { FileText, Save, Download, Sparkles, BookOpen, Clock, ChevronRight, Palette, PenLine, Keyboard, Share2 } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { toast } from 'sonner';
import { InkCanvas } from './InkCanvas';
import { VoiceCapture } from './VoiceCapture';

export const WordProcessor = ({ mode = 'default' }: { mode?: 'default' | 'journal' }) => {
  const [isPolishing, setIsPolishing] = useState(false);
  const [viewMode, setViewMode] = useState<'scribe' | 'sketch'>('scribe');
  const [entries, setEntries] = useState<{id: string, title: string, content: string, date: string}[]>([
    { id: '1', title: 'Midnight Musings', content: '<p>The bioluminescent waves today were specifically bright...</p>', date: 'Apr 22, 2026' }
  ]);
  const [activeEntry, setActiveEntry] = useState<string | null>(mode === 'journal' ? entries[0].id : null);

  const editor = useEditor({
    extensions: [
      StarterKit,
      Link.configure({ openOnClick: false }),
      Underline,
    ],
    content: mode === 'journal' ? entries[0].content : '<h1>Untitled Document</h1><p>Start writing your masterpiece...</p>',
    editorProps: {
      attributes: {
        class: 'prose prose-invert focus:outline-none max-w-none text-white/80 min-h-[500px] text-lg leading-relaxed',
      },
    },
  });

  const polishWriting = async () => {
    if (!editor || isPolishing) return;
    setIsPolishing(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const prompt = `Rewrite the following text to be more poetic, professional, and evocative. Maintain the core message but elevate the vocabulary. Output ONLY the polished HTML body:\n\n${editor.getHTML()}`;
      
      const response = await ai.models.generateContent({
        model: "gemini-1.5-flash",
        contents: prompt,
      });
      
      const polishedText = response.text;
      if (polishedText) {
        editor.commands.setContent(polishedText);
        toast.success("Writing elevated.");
      }
    } catch (error) {
      console.error('Gemini error:', error);
      toast.error("Subspace relay failed to polish text.");
    } finally {
      setIsPolishing(false);
    }
  };

  return (
    <div className="flex-1 flex overflow-hidden bg-white/[0.01]">
      {mode === 'journal' && (
        <aside className="w-80 border-r border-white/5 flex flex-col p-6 gap-6 shrink-0">
          <div className="flex items-center gap-3 mb-4">
            <BookOpen className="text-accent" />
            <h2 className="text-xl font-bold uppercase tracking-widest text-[11px]">Memories</h2>
          </div>
          <div className="flex-1 overflow-y-auto space-y-3">
            {entries.map(e => (
              <button 
                key={e.id}
                onClick={() => {
                  setActiveEntry(e.id);
                  editor?.commands.setContent(e.content);
                }}
                className={`w-full text-left p-4 rounded-2xl transition-all border ${activeEntry === e.id ? 'bg-accent/10 border-accent/20' : 'border-white/5 hover:bg-white/5'}`}
              >
                <div className="text-xs text-muted flex items-center gap-2 mb-1">
                  <Clock size={10} /> {e.date}
                </div>
                <div className="font-bold text-sm truncate">{e.title}</div>
              </button>
            ))}
            <button className="w-full py-4 border-2 border-dashed border-white/10 rounded-2xl text-[10px] uppercase font-bold text-muted hover:border-accent hover:text-white transition-all">
              + New Entry
            </button>
          </div>
        </aside>
      )}

      <main className="flex-1 flex flex-col overflow-hidden relative">
        <div className="p-6 border-b border-white/5 flex items-center justify-between bg-white/[0.02]">
          <div className="flex items-center gap-4">
            <div className={`p-2 rounded-lg ${mode === 'journal' ? 'bg-purple-500/10 text-purple-400' : 'bg-cyan-500/10 text-cyan-400'}`}>
              {mode === 'journal' ? <BookOpen size={18} /> : <FileText size={18} />}
            </div>
            <div>
              <h2 className="text-[10px] uppercase tracking-[3px] text-muted font-bold">{mode === 'journal' ? 'Journal Entry' : 'Document'}</h2>
              <div className="font-serif text-lg italic">
                {mode === 'journal' ? entries.find(e => e.id === activeEntry)?.title : 'Untitled Artifact'}
              </div>
            </div>
          </div>

          <div className="flex gap-3">
            {mode === 'journal' && (
              <div className="flex bg-white/5 p-1 rounded-xl mr-2">
                <button 
                  onClick={() => setViewMode('scribe')}
                  className={`p-2 rounded-lg transition-all flex items-center gap-2 text-[10px] uppercase font-bold px-4 ${viewMode === 'scribe' ? 'bg-accent text-white shadow-lg shadow-accent/20' : 'text-white/40 hover:text-white'}`}
                >
                  <Keyboard size={14} /> Scribe
                </button>
                <button 
                  onClick={() => setViewMode('sketch')}
                  className={`p-2 rounded-lg transition-all flex items-center gap-2 text-[10px] uppercase font-bold px-4 ${viewMode === 'sketch' ? 'bg-accent text-white shadow-lg shadow-accent/20' : 'text-white/40 hover:text-white'}`}
                >
                  <Palette size={14} /> Sketch
                </button>
              </div>
            )}
            <VoiceCapture 
              compact 
              className="mr-2"
              onTranscribe={(text) => {
                editor?.commands.insertContent(`<p>${text}</p>`);
              }}
            />
            <button 
              onClick={polishWriting}
              disabled={isPolishing}
              className="glass-button !px-6 flex items-center gap-2 text-[10px] font-bold"
            >
              {isPolishing ? <Sparkles className="animate-spin" size={12} /> : <Sparkles className="text-accent" size={12} />}
              Magic Polish
            </button>
            <button className="glass-button !px-6 !bg-accent !text-white flex items-center gap-2 text-[10px] font-bold">
              <Save size={12} /> Sync
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-hidden relative">
          <AnimatePresence mode="wait">
            {viewMode === 'scribe' ? (
              <motion.div 
                key="scribe"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="h-full overflow-y-auto p-12 lg:p-24 selection:bg-accent/30 font-serif"
              >
                <div className="max-w-4xl mx-auto">
                  <EditorContent editor={editor} />
                </div>
              </motion.div>
            ) : (
              <motion.div 
                key="sketch"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="h-full"
              >
                <InkCanvas />
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="p-4 border-t border-white/5 bg-white/[0.02] flex justify-between items-center text-[10px] uppercase tracking-widest text-muted">
           <div className="flex gap-6">
             <span>Words: {editor?.getText().split(/\s+/).length || 0}</span>
             <span>Status: Cloud Synced</span>
           </div>
           <div className="flex items-center gap-2 cursor-pointer hover:text-white transition-colors">
              Markdown Enabled <ChevronRight size={10} />
           </div>
        </div>
      </main>
    </div>
  );
};
