import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Trash2, GripVertical, Paperclip, MoreHorizontal } from 'lucide-react';

type Idea = {
  id: string;
  title: string;
  content: string;
  color: string;
  tags: string[];
};

const COLORS = [
  'bg-blue-500/20 text-blue-200 border-blue-500/30',
  'bg-purple-500/20 text-purple-200 border-purple-500/30',
  'bg-amber-500/20 text-amber-200 border-amber-500/30',
  'bg-emerald-500/20 text-emerald-200 border-emerald-500/30',
  'bg-rose-500/20 text-rose-200 border-rose-500/30',
];

export const IdeasBoard = () => {
  const [ideas, setIdeas] = useState<Idea[]>([
    { id: '1', title: 'Limestone Textures', content: 'Minimalist structural rhythm for the pavilion project.', color: 'border-rose-500/30', tags: ['architecture'] },
    { id: '2', title: 'Structural Rhythm', content: 'Focus on authentic storytelling through frosted glass textures.', color: 'border-white/20', tags: ['concept'] },
    { id: '3', title: 'The Journal Rebrand', content: 'Incorporate more white space and Georgia serif fonts.', color: 'border-rose-500/30', tags: ['design'] },
  ]);

  const addIdea = () => {
    const newIdea: Idea = {
      id: Date.now().toString(),
      title: 'New Inspiration',
      content: 'Start typing your idea here...',
      color: 'border-white/20',
      tags: [],
    };
    setIdeas([newIdea, ...ideas]);
  };

  const removeIdea = (id: string) => {
    setIdeas(ideas.filter(i => i.id !== id));
  };

  return (
    <div className="flex-1 p-10 overflow-y-auto">
      <div className="flex items-center justify-between mb-12">
        <div>
          <p className="text-muted text-[10px] mb-2 uppercase tracking-[2px]">Curation</p>
          <h2 className="display text-5xl">Mood <span className="serif-italic">Board</span></h2>
        </div>
        <button 
          onClick={addIdea}
          className="glass-button"
        >
          <span>Collect Idea</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
        <AnimatePresence>
          {ideas.map((idea, index) => (
            <motion.div
              key={idea.id}
              layout
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.4, delay: index * 0.05, ease: [0.23, 1, 0.32, 1] }}
              className={`glass-panel border-t-2 ${idea.color} p-8 min-h-[250px] flex flex-col group hover:border-accent transition-colors`}
            >
              <div className="flex items-center justify-between mb-6">
                <input 
                  defaultValue={idea.title}
                  className="bg-transparent serif-italic text-2xl focus:outline-none w-full"
                />
                <button 
                  onClick={() => removeIdea(idea.id)}
                  className="opacity-0 group-hover:opacity-100 p-2 hover:bg-white/10 rounded-full transition-all text-white/40 hover:text-rose-400"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              <textarea 
                defaultValue={idea.content}
                className="bg-transparent text-sm text-white/70 focus:outline-none flex-1 resize-none leading-relaxed font-light"
                rows={4}
              />
              <div className="mt-6 pt-6 border-t border-white/5 flex items-center justify-between">
                <div className="flex gap-3">
                  {idea.tags.map(tag => (
                    <span key={tag} className="text-[9px] uppercase tracking-widest text-accent">
                      #{tag}
                    </span>
                  ))}
                </div>
                <div className="text-[10px] text-muted">0{index + 1}</div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
};
