import React, { useState, useRef } from 'react';
import { Mic, Square, Loader2, Play, Pause, Volume2 } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { toast } from 'sonner';

interface VoiceCaptureProps {
  onTranscribe: (text: string, audioUrl?: string) => void;
  className?: string;
  compact?: boolean;
}

export const VoiceCapture = ({ onTranscribe, className, compact }: VoiceCaptureProps) => {
  const [isRecording, setIsRecording] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      chunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      recorder.onstop = async () => {
        const audioBlob = new Blob(chunksRef.current, { type: 'audio/webm' });
        const url = URL.createObjectURL(audioBlob);
        setAudioUrl(url);
        
        await transcribeAudio(audioBlob, url);
        
        // Stop all tracks in the stream
        stream.getTracks().forEach(track => track.stop());
      };

      recorder.start();
      setIsRecording(true);
      toast.info("Recording started. Speak clearly.");
    } catch (err) {
      console.error("Microphone access denied:", err);
      toast.error("Could not access microphone.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const transcribeAudio = async (blob: Blob, url: string) => {
    setIsTranscribing(true);
    try {
      const reader = new FileReader();
      reader.readAsDataURL(blob);
      reader.onloadend = async () => {
        const base64Data = (reader.result as string).split(',')[1];
        
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
        const response = await ai.models.generateContent({
          model: "gemini-3-flash-preview",
          contents: [
            {
              parts: [
                {
                  inlineData: {
                    mimeType: "audio/webm",
                    data: base64Data
                  }
                },
                {
                  text: "You are a professional transcriber. Transcribe the audio exactly as spoken. If there is no speech, return an empty string. Output ONLY the transcription text."
                }
              ]
            }
          ]
        });

        const text = response.text;
        if (text && text.trim()) {
          onTranscribe(text.trim(), url);
          toast.success("Speech transcribed.");
        } else {
          toast.error("No clear speech detected.");
        }
        setIsTranscribing(false);
      };
    } catch (error) {
      console.error("Transcription error:", error);
      toast.error("Failed to transcribe audio.");
      setIsTranscribing(false);
    }
  };

  if (compact) {
    return (
      <button 
        onClick={isRecording ? stopRecording : startRecording}
        disabled={isTranscribing}
        className={`p-2 rounded-full transition-all flex items-center justify-center ${isRecording ? 'bg-rose-500 scale-110 animate-pulse text-white' : 'bg-white/5 text-white/40 hover:text-white hover:bg-white/10'} ${className}`}
        title={isRecording ? "Stop Recording" : "Voice Note"}
      >
        {isTranscribing ? <Loader2 className="animate-spin" size={16} /> : isRecording ? <Square size={16} /> : <Mic size={16} />}
      </button>
    );
  }

  return (
    <div className={`flex flex-col gap-4 ${className}`}>
      <div className="flex items-center gap-4">
        <button 
          onClick={isRecording ? stopRecording : startRecording}
          disabled={isTranscribing}
          className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${isRecording ? 'bg-rose-500 animate-pulse text-white shadow-xl shadow-rose-500/20' : 'bg-accent text-white shadow-xl shadow-accent/20 hover:scale-105'}`}
        >
          {isTranscribing ? <Loader2 className="animate-spin" size={24} /> : isRecording ? <Square size={24} /> : <Mic size={24} />}
        </button>
        <div>
          <h3 className="font-bold text-sm">{isRecording ? "Listening..." : isTranscribing ? "Transcribing..." : "Voice Capture"}</h3>
          <p className="text-xs text-muted leading-tight">
            {isRecording ? "Recording your message..." : isTranscribing ? "Gemini is processing audio..." : "Tap the mic to dictate thoughts"}
          </p>
        </div>
      </div>
    </div>
  );
};
