import React, { useState, useEffect } from 'react';
import { Sidebar, Header, Tab, Account } from './components/Layout';
import { EmailView } from './components/EmailView';
import { CalendarView } from './components/CalendarView';
import { IdeasBoard } from './components/IdeasBoard';
import { WordProcessor } from './components/WordProcessor';
import { StickyNotes } from './components/StickyNotes';
import { InkCanvas } from './components/InkCanvas';
import { Toaster, toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';
import { Settings, Palette, User, Bell, Calendar, LogOut, Plus, Trash2 } from 'lucide-react';

export type ThemeType = 'editorial' | 'plajah' | 'focus' | 'brutalist';
export type LayoutType = 'curated' | 'classic' | 'solo';
export type ExperienceType = 'ink' | 'ocean' | 'abyss' | 'nebula' | 'planetary' | 'prism';

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('mail');
  const [theme, setTheme] = useState<ThemeType>('editorial');
  const [layout, setLayout] = useState<LayoutType>('curated');
  const [experience, setExperience] = useState<ExperienceType>('ink');
  const [showSettings, setShowSettings] = useState(false);
  const [background, setBackground] = useState<{ url: string; type: 'image' | 'video' | 'none' }>({ url: '', type: 'none' });
  
  const [accounts, setAccounts] = useState<Account[]>([
    { id: '1', type: 'gmail', email: 'alex.design@gmail.com', avatar: 'https://picsum.photos/seed/alex/100/100' }
  ]);

  const [refreshTrigger, setRefreshTrigger] = useState(0);

  useEffect(() => {
    document.body.setAttribute('data-theme', theme);
  }, [theme]);

  // OAuth logic following the oauth-integration skill
  const handleConnectAccount = async (type: 'google' | 'microsoft') => {
    try {
      const endpoint = type === 'google' ? '/api/auth/google/url' : '/api/auth/microsoft/url';
      const response = await fetch(endpoint);
      if (!response.ok) throw new Error('Failed to fetch auth URL');
      const { url } = await response.json();
      
      const authWindow = window.open(url, 'oauth_popup', 'width=600,height=700');
      if (!authWindow) {
        toast.error('Popup blocked. Please enable popups to connect your account.');
      }
    } catch (error) {
      console.error('Connection error:', error);
      toast.error('Could not initiate connection.');
    }
  };

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      // Validate origin
      if (!event.origin.endsWith('.run.app') && !event.origin.includes('localhost')) return;
      
      if (event.data?.type === 'OAUTH_AUTH_SUCCESS') {
        const provider = event.data.provider;
        toast.success(`Successfully connected ${provider === 'google' ? 'Gmail' : 'Outlook'} account!`);
        setRefreshTrigger(prev => prev + 1);
        
        // Mocking the addition of the new account for the sidebar UI
        const newAcc: Account = {
          id: Date.now().toString(),
          type: provider === 'google' ? 'gmail' : 'outlook',
          email: provider === 'google' ? 'new.user@gmail.com' : 'new.user@outlook.com',
          avatar: `https://picsum.photos/seed/${provider}/100/100`
        };
        setAccounts(prev => [...prev, newAcc]);
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  return (
    <div className={`flex h-screen w-screen p-6 gap-6 overflow-hidden relative box-border transition-all duration-700 ${theme === 'focus' ? 'p-0 gap-0' : ''}`}>
      {/* Dynamic Background */}
      {background.type !== 'none' && (
        <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
          {background.type === 'image' ? (
            <img src={background.url} className="w-full h-full object-cover opacity-30 blur-sm scale-110" referrerPolicy="no-referrer" />
          ) : (
            <video 
              src={background.url} 
              autoPlay 
              loop 
              muted 
              playsInline 
              className="w-full h-full object-cover opacity-20 blur-md scale-105" 
            />
          )}
        </div>
      )}

      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        accounts={accounts} 
        onConnect={handleConnectAccount}
        theme={theme}
        setTheme={setTheme}
        layout={layout}
        setLayout={setLayout}
        experience={experience}
        setExperience={setExperience}
        onOpenSettings={() => setShowSettings(true)}
      />
      
      <main className={`flex-1 flex flex-col min-w-0 transition-all duration-700 z-10 ${layout === 'solo' ? 'max-w-4xl mx-auto' : ''}`}>
        <Header 
          title={
            activeTab === 'mail' ? 'The Post Man' : 
            activeTab === 'calendar' ? 'Schedule' : 
            activeTab === 'editor' ? 'Processor' :
            activeTab === 'journal' ? 'Journal' :
            activeTab === 'sticky' ? 'Sticky Station' :
            'Mood Board'
          } 
          theme={theme}
          experience={experience}
          setExperience={setExperience}
        />
        
        <div className="flex-1 overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.div
              key={`${activeTab}-${layout}-${theme}-${experience}`}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
              className="h-full w-full flex glass-panel overflow-hidden"
            >
              {activeTab === 'mail' && (
                <EmailView 
                  refreshTrigger={refreshTrigger} 
                  layout={layout} 
                  experience={experience} 
                />
              )}
              {activeTab === 'calendar' && <CalendarView />}
              {activeTab === 'board' && <IdeasBoard />}
              {activeTab === 'editor' && <WordProcessor />}
              {activeTab === 'journal' && <WordProcessor mode="journal" />}
              {activeTab === 'sticky' && <StickyNotes />}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Editorial aesthetic panel pattern - hide in focus or solo layout */}
      {theme !== 'focus' && layout !== 'solo' && (
        <div className="hidden xl:flex w-64 flex-col gap-6 z-10">
          <div className="glass-panel p-6 flex-1 flex flex-col overflow-hidden">
            <div className="text-[10px] uppercase tracking-widest text-muted mb-6">Inspiration</div>
            <div className="flex flex-col gap-4 overflow-y-auto pr-1">
              <div className="h-32 bg-white/5 border border-white/10 rounded-xl overflow-hidden relative flex-shrink-0">
                <img src={`https://picsum.photos/seed/${theme}/400/300`} className="w-full h-full object-cover opacity-50" referrerPolicy="no-referrer" />
                <div className="absolute bottom-2 left-2 text-[10px] bg-black/40 px-2 py-1 rounded">Visual Concept #01</div>
              </div>
              <div className="p-4 bg-accent/10 border border-accent/20 rounded-xl text-xs leading-relaxed text-accent serif-italic italic">
                {theme === 'editorial' && '"Simplicity is the ultimate sophistication."'}
                {theme === 'plajah' && '"Life is better at the beach."'}
                {theme === 'brutalist' && '"Form follows function."'}
              </div>
            </div>
          </div>

          <div className="glass-panel p-6 h-48 flex flex-col">
            <div className="text-[10px] uppercase tracking-widest text-muted mb-4">Upcoming</div>
            <div className="flex-1 overflow-y-auto space-y-4 pr-1">
              <div className="flex gap-3 items-start">
                <div className="text-accent font-bold text-sm">24</div>
                <div className="text-xs">
                  <div>Design Sync</div>
                  <div className="opacity-40">02:00 PM - Outlook</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <AnimatePresence>
        {showSettings && (
          <SettingsModal 
            onClose={() => setShowSettings(false)} 
            background={background}
            setBackground={setBackground}
            accounts={accounts}
          />
        )}
      </AnimatePresence>

      <Toaster theme={theme === 'plajah' || theme === 'focus' ? 'light' : 'dark'} position="bottom-right" />
    </div>
  );
}

const SettingsModal = ({ onClose, background, setBackground, accounts }: any) => {
  const [activeSection, setActiveSection] = useState('general');

  const sections = [
    { id: 'general', label: 'General', icon: <Settings size={16} /> },
    { id: 'personalization', label: 'Personalization', icon: <Palette size={16} /> },
    { id: 'accounts', label: 'Accounts', icon: <User size={16} /> },
    { id: 'notifications', label: 'Notifications', icon: <Bell size={16} /> },
    { id: 'calendar', label: 'Calendar', icon: <Calendar size={16} /> },
  ];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const url = URL.createObjectURL(file);
    const type = file.type.startsWith('video') ? 'video' : 'image';
    setBackground({ url, type });
    toast.success(`${type.charAt(0).toUpperCase() + type.slice(1)} background applied.`);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/60 backdrop-blur-md"
      onClick={onClose}
    >
      <motion.div 
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        onClick={e => e.stopPropagation()}
        className="w-full max-w-5xl h-[80vh] glass-panel bg-[#0f1218] border-white/10 shadow-2xl flex overflow-hidden"
      >
        {/* Sidebar */}
        <aside className="w-64 border-r border-white/5 flex flex-col p-6 gap-2">
          <h2 className="text-xl font-bold mb-8 px-4">Settings</h2>
          {sections.map(s => (
            <button
              key={s.id}
              onClick={() => setActiveSection(s.id)}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all text-sm ${activeSection === s.id ? 'bg-accent/10 text-accent font-bold' : 'text-white/40 hover:bg-white/5 hover:text-white'}`}
            >
              {s.icon}
              {s.label}
            </button>
          ))}
          <button 
            onClick={onClose}
            className="mt-auto flex items-center gap-3 px-4 py-3 rounded-xl text-white/40 hover:text-white transition-all text-sm"
          >
            <LogOut size={16} /> Close
          </button>
        </aside>

        {/* Content */}
        <main className="flex-1 flex flex-col overflow-hidden">
          <div className="p-10 overflow-y-auto">
            {activeSection === 'general' && (
              <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2">
                <div>
                  <h3 className="text-2xl font-bold mb-2">General Settings</h3>
                  <p className="text-sm text-muted">Manage your core application experience.</p>
                </div>
                <div className="space-y-6">
                  <SettingItem label="Language" description="Select your preferred language.">
                    <select className="bg-white/5 border border-white/10 rounded-lg px-3 py-1 text-sm focus:outline-none">
                      <option>English (US)</option>
                      <option>Spanish</option>
                      <option>French</option>
                    </select>
                  </SettingItem>
                  <SettingItem label="Time Zone" description="Automatically detect your location.">
                    <button className="text-accent underline text-sm font-medium">Detect Location</button>
                  </SettingItem>
                  <SettingItem label="Density" description="Adjust the visual tightness of the mail list.">
                    <div className="flex bg-white/5 p-1 rounded-lg">
                      <button className="px-3 py-1 text-xs rounded-md bg-accent text-white">Curated</button>
                      <button className="px-3 py-1 text-xs rounded-md">Compact</button>
                    </div>
                  </SettingItem>
                </div>
              </div>
            )}

            {activeSection === 'personalization' && (
              <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2">
                <div>
                  <h3 className="text-2xl font-bold mb-2">Personalization</h3>
                  <p className="text-sm text-muted">Make The Post Man yours with custom backgrounds.</p>
                </div>
                <div className="space-y-6">
                  <div className="p-10 border-2 border-dashed border-white/10 rounded-3xl flex flex-col items-center justify-center gap-6 bg-white/[0.02] hover:bg-white/[0.04] transition-all relative overflow-hidden group">
                    {background.type !== 'none' && (
                      <div className="absolute inset-0 opacity-20 group-hover:scale-110 transition-transform">
                        {background.type === 'image' ? <img src={background.url} className="w-full h-full object-cover" /> : <video src={background.url} className="w-full h-full object-cover" muted loop autoPlay />}
                      </div>
                    )}
                    <div className="relative z-10 flex flex-col items-center">
                      <div className="w-16 h-16 rounded-full bg-accent/20 flex items-center justify-center mb-4 text-accent">
                        <Plus size={32} />
                      </div>
                      <h4 className="font-bold">Active Background</h4>
                      <p className="text-xs text-muted mb-6">Drop an image or looping video (mp4)</p>
                      <div className="flex gap-4">
                        <label className="bg-accent hover:brightness-110 px-6 py-2 rounded-full text-xs font-bold cursor-pointer transition-all">
                          Upload File
                          <input type="file" className="hidden" accept="image/*,video/*" onChange={handleFileUpload} />
                        </label>
                        {background.type !== 'none' && (
                          <button 
                            onClick={() => setBackground({ url: '', type: 'none' })}
                            className="bg-white/5 hover:bg-white/10 px-6 py-2 rounded-full text-xs font-bold transition-all border border-white/10"
                          >
                            Reset
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4">
                    {['Nature', 'Tech', 'Abstract'].map(p => (
                      <button key={p} className="h-24 rounded-2xl bg-white/5 border border-white/5 flex items-center justify-center text-xs font-bold text-muted hover:border-accent hover:text-white transition-all uppercase tracking-widest">
                        {p} Preset
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeSection === 'accounts' && (
              <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2">
                <div>
                  <h3 className="text-2xl font-bold mb-2">Connected Accounts</h3>
                  <p className="text-sm text-muted">Sync your letters from Gmail and Outlook.</p>
                </div>
                <div className="space-y-4">
                  {accounts.map((acc: any) => (
                    <div key={acc.id} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/10">
                      <div className="flex items-center gap-4">
                        <img src={acc.avatar} className="w-10 h-10 rounded-full" alt="" />
                        <div>
                          <div className="font-bold text-sm uppercase tracking-tight">{acc.type}</div>
                          <div className="text-xs text-muted leading-none">{acc.email}</div>
                        </div>
                      </div>
                      <button className="p-2 hover:bg-rose-500/10 text-rose-400 rounded-full transition-all group">
                         <Trash2 size={16} className="group-hover:scale-110" />
                      </button>
                    </div>
                  ))}
                  <button className="w-full py-4 border-2 border-dashed border-white/10 rounded-2xl text-xs font-bold text-muted hover:border-accent hover:text-white transition-all uppercase tracking-widest flex items-center justify-center gap-2">
                    <Plus size={14} /> Add New Account
                  </button>
                </div>
              </div>
            )}
          </div>
        </main>
      </motion.div>
    </motion.div>
  );
};

const SettingItem = ({ label, description, children }: any) => (
  <div className="flex items-center justify-between py-4 border-b border-white/5 last:border-0">
    <div className="flex-1">
      <h4 className="font-bold text-sm">{label}</h4>
      <p className="text-xs text-muted">{description}</p>
    </div>
    <div className="flex-shrink-0 ml-10">
      {children}
    </div>
  </div>
);
