/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Script } from './types';
import { SAMPLE_SCRIPTS } from './data/sampleScripts';
import EditorScreen from './components/EditorScreen';
import OperatorConsole from './components/OperatorConsole';
import PrompterScreen from './components/PrompterScreen';

export default function App() {
  const [scripts, setScripts] = useState<Script[]>([]);
  const [activeScript, setActiveScript] = useState<Script | null>(null);
  const [viewMode, setViewMode] = useState<'editor' | 'solo' | 'operator' | 'prompter'>('editor');

  // Load scripts on mount
  useEffect(() => {
    // 1. Check URL parameters for explicit role query (e.g. ?role=prompter)
    const params = new URLSearchParams(window.location.search);
    const roleParam = params.get('role');

    if (roleParam === 'prompter') {
      setViewMode('prompter');
      return;
    }

    // 2. Load custom scripts from localStorage, fallback to samples
    const stored = localStorage.getItem('teleprompter_scripts');
    if (stored) {
      try {
        const parsed = JSON.parse(stored) as Script[];
        if (parsed.length > 0) {
          setScripts(parsed);
          setActiveScript(parsed[0]);
          return;
        }
      } catch (err) {
        console.error('Failed to parse stored scripts:', err);
      }
    }

    // Initialize with samples
    setScripts(SAMPLE_SCRIPTS);
    setActiveScript(SAMPLE_SCRIPTS[0]);
    localStorage.setItem('teleprompter_scripts', JSON.stringify(SAMPLE_SCRIPTS));
  }, []);

  // Save/Update scripts to localStorage
  const handleSaveScript = (updated: Script) => {
    setScripts((prev) => {
      const idx = prev.findIndex((s) => s.id === updated.id);
      let next: Script[];
      if (idx > -1) {
        next = [...prev];
        next[idx] = updated;
      } else {
        next = [updated, ...prev];
      }
      localStorage.setItem('teleprompter_scripts', JSON.stringify(next));
      return next;
    });

    if (activeScript?.id === updated.id || !activeScript) {
      setActiveScript(updated);
    }
  };

  // Delete a script
  const handleDeleteScript = (id: string) => {
    setScripts((prev) => {
      const next = prev.filter((s) => s.id !== id);
      localStorage.setItem('teleprompter_scripts', JSON.stringify(next));
      
      // Update active script if deleted
      if (activeScript?.id === id) {
        setActiveScript(next[0] || null);
      }
      return next;
    });
  };

  // Restore sample scripts
  const handleResetSamples = () => {
    setScripts(SAMPLE_SCRIPTS);
    setActiveScript(SAMPLE_SCRIPTS[0]);
    localStorage.setItem('teleprompter_scripts', JSON.stringify(SAMPLE_SCRIPTS));
    setViewMode('editor');
  };

  // Triggered when clicking Solo, operator or prompter launch from the editor
  const handleSelectScript = (script: Script, mode: 'solo' | 'operator' | 'prompter') => {
    setActiveScript(script);
    setViewMode(mode);
  };

  // Render correct dashboard screen
  switch (viewMode) {
    case 'prompter':
      return (
        <PrompterScreen
          initialScriptTitle={activeScript?.title || 'Waiting for script...'}
          initialScriptContent={activeScript?.content || '# [No Script Loaded]\nOpen the Operator Console and select a script to begin scrolling.'}
          isStandalone={false}
        />
      );

    case 'solo':
      return (
        <PrompterScreen
          initialScriptTitle={activeScript?.title || 'Solo Prompt'}
          initialScriptContent={activeScript?.content || ''}
          isStandalone={true}
          onExit={() => setViewMode('editor')}
        />
      );

    case 'operator':
      return activeScript ? (
        <OperatorConsole
          scriptId={activeScript.id}
          scriptTitle={activeScript.title}
          scriptContent={activeScript.content}
          onBackToDashboard={() => setViewMode('editor')}
        />
      ) : (
        <div className="flex items-center justify-center h-screen bg-zinc-950 text-white">
          <p>No active script found. Please go back to dashboard.</p>
        </div>
      );

    case 'editor':
    default:
      return (
        <EditorScreen
          scripts={scripts}
          onSaveScript={handleSaveScript}
          onDeleteScript={handleDeleteScript}
          onSelectScript={handleSelectScript}
          onResetSamples={handleResetSamples}
        />
      );
  }
}
